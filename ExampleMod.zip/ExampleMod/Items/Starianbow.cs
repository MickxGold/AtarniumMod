using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ExampleMod.Items
{
  public class Starianbow : ModItem
  {
  public override void SetStaticDefaults()
  {
  DisplayName.SetDefault("Starian Bow");
  Tooltip.SetDefault("A light and basic bow.");
  }

  public override void SetDefaults()
  {
  item.damage = 14;
  item.ranged = true;
  item.width = 16;
  item.height = 32;
  item.maxStack = 1;
  item.useTime = 28;
  item.useAnimation = 28;
  item.useStyle = 5;
  item.knockBack = 2;
  item.value = 3400;
  item.rare = 1;
  item.UseSound = SoundID.Item5;
  item.noMelee = true;
  item.shoot = 1;
  item.useAmmo = AmmoID.Arrow;
  item.shootSpeed = 10f;
  item.autoReuse = false;
  }
  }
}