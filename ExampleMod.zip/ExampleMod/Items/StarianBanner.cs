using Terraria.ID;
using Terraria.ModLoader;

namespace ExampleMod.Items
{
	public class StarianBanner : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Starait Banner");
			Tooltip.SetDefault("This may Attract a Traveler from far away.");
		}

		public override void SetDefaults()
		{
			item.width = 20;
			item.height = 20;
			item.maxStack = 1;
			item.value = 300;
			item.rare = 2;
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.DirtBlock);
			recipe.SetResult(this, 1);
			recipe.AddRecipe();
			recipe = new ModRecipe(mod);
			recipe.AddRecipeGroup("ExampleMod:ExampleItem");
			recipe.SetResult(this, 1);
			recipe.AddRecipe();
	
	    }
    }
}